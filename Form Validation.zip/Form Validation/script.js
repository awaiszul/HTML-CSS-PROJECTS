const title = document.getElementById('title');
const name = document.getElementById('name');
const loginBtn = document.getElementById('loginBtn');
const signUpBtn = document.getElementById('signUpBtn');
const forgotPassword = document.getElementById('FgPass');
const signUp = document.querySelector('.signUp')
const signIn = document.querySelector('.switch')

signUpBtn.onclick = ()=>{
    title.innerHTML = "Sign Up";
    name.style.display = "block";
    loginBtn.value = "Sign Up"
    forgotPassword.style.display = "none";
    signUp.style.display = "none"
    signIn.style.display = "block"
}

signIn.onclick = ()=>{
    title.innerHTML = "Login";
    name.style.display = "none";
    loginBtn.value = "Login"
    forgotPassword.style.display = "block";
    signUp.style.display = "block"
    signIn.style.display = "none"
}

